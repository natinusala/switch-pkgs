# switch-libuuid
libuuid port for libnx (Switch homebrew)

Install it via my packages repo
